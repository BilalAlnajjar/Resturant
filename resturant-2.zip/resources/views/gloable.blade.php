@extends('layouts.home')
@section('content')
<global-home></global-home>
@endsection
